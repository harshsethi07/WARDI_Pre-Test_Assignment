package com.example.penny.wardi;
/*
    REFRENCES:
    https://code.tutsplus.com/tutorials/android-sensors-in-depth-proximity-and-gyroscope--cms-28084

 */

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private SensorEventListener gyroListener;
    private Sensor gyroSensor;
    boolean b = true;

//    private void toggleMsg( )
//    {
//        if (b == true)
//            m = "See, I told you";
//        else
//            m = "Don’t you get bored of me";
//
//        b = !b;
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView msg = (TextView) findViewById(R.id.message);


        Button reset = ( Button ) findViewById(R.id.reset);     //to reset the message
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                msg.setText(R.string.msg_own);
            }
        });



        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        //checking if the sensor if available
        if(gyroSensor == null) {
            msg.setText("Gyroscope Sensor Not Available!");
        }


        else
        {
            gyroListener = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent sensorEvent)
                {

                    if (sensorEvent.values[1] < -0.6f)
                    {
                        msg.setText(R.string.msg_friend);
                        b = false;
                    }

                    else if (sensorEvent.values[1] > 0.6f )
                    {
                        msg.setText(R.string.msg_own);
                        b = true;
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int i) {

                }
            };

            sensorManager.registerListener(gyroListener, gyroSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(gyroListener);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        sensorManager.registerListener(gyroListener, gyroSensor, SensorManager.SENSOR_DELAY_NORMAL);

    }
}
